# Dapper Dasher

Dapper Dasher is a runner game where the character dashes out of the way of flying hazards!